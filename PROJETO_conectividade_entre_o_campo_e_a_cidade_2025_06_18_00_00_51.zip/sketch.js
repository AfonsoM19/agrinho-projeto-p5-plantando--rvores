let tratorX = 50;
let caminhaoX = 550;
let estradaY;
let torreX = 300;
let conectado = false;
let botao;

let caixasTrator = [];

function setup() {
  createCanvas(600, 400);
  estradaY = height / 2;

  botao = createButton("Conectar");
  botao.position(20, 20);
  botao.mousePressed(ativarConexao);

  for (let i = 0; i < 3; i++) {
    caixasTrator.push({ x: tratorX - i * 15, y: estradaY - 35 });
  }
}

function draw() {
  background(135, 206, 235);
  desenharEstrada();
  desenharCampoCidade();
  desenharPrediosMargemBaixoCidade();
  desenharVacas();
  desenharTorre();
  desenharTrator(tratorX, estradaY - 20);
  desenharCaminhao(caminhaoX, estradaY + 20);
  desenharCarroParado(100, estradaY - 70);
  desenharConexao();
  desenharCaixas();

  moverCaixas();

  tratorX += 1;
  caminhaoX -= 1;

  if (tratorX > width + 50) {
    tratorX = -50;
    caixasTrator = [];
    for (let i = 0; i < 3; i++) {
      caixasTrator.push({ x: tratorX - i * 15, y: estradaY - 35 });
    }
  }

  if (caminhaoX < -50) {
    caminhaoX = width + 50;
  }

  if (conectado) {
    fill(255, 255, 0);
    textSize(16);
    noStroke();
    text("📦 Conexão entre o campo e a cidade ativada!", 150, 30);
  }
}

function ativarConexao() {
  conectado = !conectado;
}

function desenharEstrada() {
  fill(50);
  rect(0, estradaY - 40, width, 80);
  stroke(255);
  strokeWeight(2);
  for (let i = 0; i < width; i += 40) {
    line(i, estradaY, i + 20, estradaY);
  }
  noStroke();
}

function desenharCampoCidade() {
  fill(34, 139, 34);
  rect(0, 0, width / 2, estradaY - 40);

  fill(169, 169, 169);
  rect(width / 2, estradaY + 40, width / 2, height - estradaY - 40);
}

function desenharPrediosMargemBaixoCidade() {
  let predioAltura = 120;
  let espacamento = 60;
  let yBase = height - predioAltura;

  // Três prédios encostados na margem de baixo, lado direito (cidade)
  let inicioX = width / 2 + 20;

  for (let i = 0; i < 3; i++) {
    let x = inicioX + i * espacamento;
    fill(100, 100, 150);
    rect(x, yBase, 50, predioAltura);

    // Janelas amarelas acesas
    fill(255, 255, 0);
    for (let j = 0; j < 4; j++) {
      rect(x + 10, yBase + 15 + j * 25, 12, 18);
      rect(x + 28, yBase + 15 + j * 25, 12, 18);
    }
  }
}

function desenharVacas() {
  desenharVaca(80, 100);
  desenharVaca(150, 60);
  desenharVaca(200, 130);
}

function desenharVaca(x, y) {
  fill(255);
  rect(x, y, 30, 20);
  fill(0);
  ellipse(x + 5, y + 20, 6);
  ellipse(x + 25, y + 20, 6);
  fill(255);
  ellipse(x + 30, y, 15);
  fill(0);
  ellipse(x + 26, y - 3, 4);
  ellipse(x + 34, y - 3, 4);
  fill(255, 192, 203);
  ellipse(x + 30, y + 4, 6, 3);
}

function desenharTorre() {
  fill(150);
  rect(torreX - 10, estradaY - 100, 20, 100);
  fill(255, 0, 0);
  ellipse(torreX, estradaY - 100, 20, 20);
}

function desenharConexao() {
  stroke(conectado ? color(255, 255, 0) : color(0, 255, 0));
  strokeWeight(2);
  line(tratorX + 20, estradaY - 20, torreX, estradaY - 100);
  line(caminhaoX - 20, estradaY + 20, torreX, estradaY - 100);
  noStroke();
}

function desenharTrator(x, y) {
  fill(0, 100, 0);
  rect(x, y - 20, 40, 20);
  fill(255, 255, 0);
  rect(x + 10, y - 40, 20, 20);
  fill(0);
  ellipse(x + 10, y, 10, 10);
  ellipse(x + 30, y, 10, 10);

  fill(255, 220, 180);
  ellipse(x + 20, y - 30, 10, 10);
  fill(0);
  ellipse(x + 18, y - 31, 2, 2);
  ellipse(x + 22, y - 31, 2, 2);
  stroke(0);
  line(x + 20, y - 25, x + 20, y - 20);
  noStroke();
}

function desenharCaminhao(x, y) {
  fill(0, 0, 255);
  rect(x - 40, y - 20, 60, 20);
  fill(255);
  rect(x + 20, y - 30, 20, 30);
  fill(0);
  ellipse(x - 30, y, 12, 12);
  ellipse(x - 10, y, 12, 12);

  fill(255, 220, 180);
  ellipse(x + 30, y - 25, 10, 10);
  fill(0);
  ellipse(x + 28, y - 26, 2, 2);
  ellipse(x + 32, y - 26, 2, 2);
  stroke(0);
  line(x + 30, y - 20, x + 30, y - 15);
  noStroke();
}

function desenharCaixas() {
  fill(139, 69, 19);
  for (let caixa of caixasTrator) {
    rect(caixa.x, caixa.y, 10, 10);
  }
}

function moverCaixas() {
  for (let caixa of caixasTrator) {
    caixa.x += 1;
  }
  caixasTrator = caixasTrator.filter(caixa => caixa.x < width);
}

function desenharCarroParado(x, y) {
  fill(200, 0, 0);
  rect(x, y, 40, 20);

  fill(255);
  rect(x + 10, y - 10, 20, 15);

  fill(0);
  ellipse(x + 10, y + 20, 12, 12);
  ellipse(x + 30, y + 20, 12, 12);

  // Homem simples
  fill(255, 220, 180);
  ellipse(x + 25, y - 5, 10, 10); // cabeça
  rect(x + 20, y, 10, 10); // corpo

  // Balão de fala
  fill(255);
  stroke(0);
  strokeWeight(1);
  rect(x + 45, y - 32, 110, 28, 5);
  triangle(x + 45, y - 15, x + 50, y - 15, x + 48, y - 10);
  noStroke();

  fill(0);
  textSize(14);
  textAlign(LEFT, CENTER);
  text("Olha as vacas!", x + 50, y - 16);
}














